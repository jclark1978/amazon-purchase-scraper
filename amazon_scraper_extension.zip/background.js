chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "download_csv") {
        const data = request.data;
        if (!data || !data.length) return;

        // Define CSV headers
        const headers = ["Order Date", "Order Total", "Order Number", "Items", "Order Link", "Return Eligible", "Return Date"];

        // Convert data to CSV format
        const csvRows = [];
        csvRows.push(headers.join(','));

        for (const row of data) {
            const values = [
                `"${(row.date || '').replace(/"/g, '""')}"`,
                `"${(row.total || '').replace(/"/g, '""')}"`,
                `"${(row.orderId || '').replace(/"/g, '""')}"`,
                `"${(row.items || '').replace(/"/g, '""')}"`,
                `"${(row.link || '').replace(/"/g, '""')}"`,
                `"${(row.returnEligible || '').replace(/"/g, '""')}"`,
                `"${(row.returnDate || '').replace(/"/g, '""')}"`
            ];
            csvRows.push(values.join(','));
        }

        const csvString = csvRows.join('\n');

        // Create Data URI. EncodeURIComponent handles all characters properly for the CSV content.
        const dataUrl = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csvString);

        const timestamp = new Date().toISOString().slice(0, 10);

        chrome.downloads.download({
            url: dataUrl,
            filename: `amazon_orders_auto_${timestamp}.csv`,
            saveAs: true
        });
    }
});
