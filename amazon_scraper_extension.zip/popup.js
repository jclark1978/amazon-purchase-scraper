document.addEventListener('DOMContentLoaded', () => {
    const scrapeBtn = document.getElementById('scrapeBtn');
    const scrapeAllBtn = document.getElementById('scrapeAllBtn');
    const statusDiv = document.getElementById('status');

    function setStatus(message, type = 'info') {
        statusDiv.textContent = message;
        statusDiv.className = type;
    }

    scrapeBtn.addEventListener('click', async () => {
        setStatus('Checking current tab...', 'info');
        scrapeBtn.disabled = true;

        try {
            // Get the active tab
            let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

            if (!tab.url || !tab.url.includes('amazon.com')) {
                setStatus('Please navigate to Amazon "Your Orders" page first.', 'error');
                scrapeBtn.disabled = false;
                return;
            }
            if (!tab.url.includes('your-orders') && !tab.url.includes('order-history')) {
                setStatus('Warning: Not heavily tested on this Amazon page.', 'error');
                // Don't disable immediately, let them try it.
            }

            setStatus('Injecting script...', 'info');

            // Inject the content script
            await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ['content.js']
            });

            setStatus('Scraping data...', 'info');

            // Listen for the response from the content script
            chrome.tabs.sendMessage(tab.id, { action: "scrape_orders" }, (response) => {
                if (chrome.runtime.lastError) {
                    console.error(chrome.runtime.lastError);
                    setStatus('Error communicating with page. Try refreshing.', 'error');
                    scrapeBtn.disabled = false;
                    return;
                }

                if (response && response.success) {
                    if (!response.data || response.data.length === 0) {
                        setStatus('No orders found on this page.', 'error');
                        scrapeBtn.disabled = false;
                        return;
                    }

                    setStatus(`Found ${response.data.length} orders. Downloading...`, 'success');
                    downloadCSV(response.data);

                    setTimeout(() => {
                        setStatus('Done!', 'success');
                        scrapeBtn.disabled = false;
                    }, 1500);
                } else {
                    setStatus(response?.error || 'Unknown error occurred.', 'error');
                    scrapeBtn.disabled = false;
                }
            });

        } catch (error) {
            console.error('Scraping error:', error);
            setStatus('An error occurred. See console.', 'error');
            scrapeBtn.disabled = false;
        }
    });

    function downloadCSV(data) {
        if (!data || !data.length) return;

        // Define CSV headers
        const headers = ["Order Date", "Order Total", "Order Number", "Items", "Order Link", "Return Eligible", "Return Date"];

        // Convert data to CSV format
        const csvRows = [];
        csvRows.push(headers.join(','));

        for (const row of data) {
            const values = [
                `"${(row.date || '').replace(/"/g, '""')}"`,
                `"${(row.total || '').replace(/"/g, '""')}"`,
                `"${(row.orderId || '').replace(/"/g, '""')}"`,
                `"${(row.items || '').replace(/"/g, '""')}"`,
                `"${(row.link || '').replace(/"/g, '""')}"`,
                `"${(row.returnEligible || '').replace(/"/g, '""')}"`,
                `"${(row.returnDate || '').replace(/"/g, '""')}"`
            ];
            csvRows.push(values.join(','));
        }

        const csvString = csvRows.join('\n');
        const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);

        const timestamp = new Date().toISOString().slice(0, 10);

        chrome.downloads.download({
            url: url,
            filename: `amazon_orders_${timestamp}.csv`,
            saveAs: true
        });
    }

    function resetButtons() {
        scrapeBtn.disabled = false;
        if (scrapeAllBtn) scrapeAllBtn.disabled = false;
    }

    scrapeAllBtn.addEventListener('click', async () => {
        setStatus('Checking current tab...', 'info');
        scrapeBtn.disabled = true;
        scrapeAllBtn.disabled = true;

        try {
            let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

            if (!tab.url || !tab.url.includes('amazon.com')) {
                setStatus('Please navigate to Amazon "Your Orders" page first.', 'error');
                resetButtons();
                return;
            }

            setStatus('Starting auto-scrape...', 'info');

            // Initialize storage and reload page to start the content script auto-scrape loop
            chrome.storage.local.set({ isAutoScraping: true, scrapedData: [] }, () => {
                chrome.tabs.reload(tab.id);
                // Status for the popup before it closes
                setStatus('Auto-scraping started. You can close this popup.', 'success');
            });

        } catch (error) {
            console.error('Auto-scrape init error:', error);
            setStatus('Error starting auto-scrape.', 'error');
            resetButtons();
        }
    });

});
